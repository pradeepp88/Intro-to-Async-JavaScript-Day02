import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'apidemo';
  todo$!: Observable<any>;
  //
  constructor(private http : HttpClient) { };
  //
  ngOnInit(): void {
    this.todo$ = this.http.get(
      'https://jsonplaceholder.typicode.com/todos/1'
    );
    this.todo$.subscribe(data => {this.title=(data.title)});
  }
}
//
